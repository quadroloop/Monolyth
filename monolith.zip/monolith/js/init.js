//init.js
// Bryce Mercines 2017

var loadcount = -1;
var logmin = 0;
function loadsync() {
 	var x = document.getElementById("weblink").value;
 	if ( x == [ ] ){

 	}else{
 		loadchk();
 	}
 }