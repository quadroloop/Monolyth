//monolythics.js
//Bryce Mercines 2017

//update analytics data.
var pvarray = [ ];
function subloop() {
  var pageviews  = localStorage.getItem("pg");
  var users  = localStorage.getItem("pg");
  document.getElementById("pagev").innerHTML = pageviews;
  document.getElementById("usr").innerHTML = pageviews;
  document.getElementById("source").src = "monolythics.php";
  if ( pvarray.indexOf( pageviews ) > -1 ){
  	//do nothing
  }else{
  	pvarray.push(pageviews);
  	addsimln();
  }
  setTimeout("subloop()",100);
}

var pvscale = function(){return pvarray;}